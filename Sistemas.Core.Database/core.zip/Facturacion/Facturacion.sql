CREATE SCHEMA Facturacion;
GO
