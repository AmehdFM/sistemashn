CREATE SCHEMA Configuracion;
GO
